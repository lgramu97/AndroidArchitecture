package com.anncode.offersandcoupons.model

interface CouponRepository {

    fun getCouponsAPI()
}